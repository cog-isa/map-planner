#ifndef SEARCHRESULT_H
#define SEARCHRESULT_H
#include <list>
#include "node.h"
struct SearchResult
{
        bool straight_line;
        int  lu_i;
        int  lu_j;
        int  rb_i;
        int  rb_j;

};

#endif
